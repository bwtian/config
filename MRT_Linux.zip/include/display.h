#define ALLCAT	0
#define ONECAT  1
#define GEN1    2
#define GEN2    3

#ifndef _IBMR2
#ifdef unix
#define curent curent_
#define curcat curcat_
#endif
#endif
